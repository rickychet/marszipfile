#include "mesh.h"
using namespace glm;
Cylinder::Cylinder(int stacks, int slices){
	iniMesh(stacks, slices);
}

void Cylinder::calculateVertices() {
	float x, y, z, r = 10.0f, angle;
	float angleSlice = PI * 2 / (float) slices;
	float yStack = 3 * r / (float) stacks;
	int ctr = 0;
	for (int i = 0; i < stacks + 1; i++) {
		y = r - yStack * i;
		for (int j = 0; j < slices + 1; j++) {
			angle = angleSlice * j;
			x = r * cos(angle);
			z = r * sin(angle);
			vertices[ctr].x = x;
			vertices[ctr].y = y;
			vertices[ctr].z = z;
			ctr++;
		}
	}
}

void Cylinder::calculateNormals(){
	vec2 rowCol;
	int row, col;
	for (int i = 0; i < size; i++) {
		getNeighbors(i);
		rowCol = getRowCol(i);
		row = (int)rowCol.x;
		col = (int)rowCol.y;

		// top row & bottom row 4 triangles
		if (row == 0 || row == stacks) {
			vec3 sum = vec3(0.0f);
			vec3 result;
			vec3 ori = vertices[i];
			float num = 3;
			if (row == 0) {
				for (int i = 1; i < 4; i++) {
					sum += normalizedNormal(ori, vertices[neighbors[i]], vertices[neighbors[i + 1]]);
				}
			}
			else {
				sum += normalizedNormal(ori, vertices[neighbors[0]], vertices[neighbors[1]]);
				sum += normalizedNormal(ori, vertices[neighbors[4]], vertices[neighbors[5]]);
				sum += normalizedNormal(ori, vertices[neighbors[5]], vertices[neighbors[0]]);
			}
			result = vec3(sum.x / num, sum.y / num, sum.z / num);
			normals[i] = result;
		}
		else {
			baseNormal(i);
		}
	}
}

int* Cylinder::getNeighbors(int index) {
	return cylinNeighbors(index);
}