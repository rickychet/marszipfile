#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif
#include "globals.h"
#include "model.h"
#include "mesh.h"
// for ctime
#include <chrono>
//for vertex check
#include <vector>

#define GL_LOG_FILE "gl.log"

using namespace std;
using namespace glm;

GLuint shader_programme;

GLFWwindow* window;

// keep track of window size for things like the viewport and the mouse cursor
int g_gl_width = 1024;
int g_gl_height = 768;

mat4 view_mat = mat4(1.0);
mat4 projectMat;

GLuint
	VertexShaderId,
	FragmentShaderId,
	ProgramId,
	ColorBufferId;

int viewLocation, projectionLocation, modelLocation, fragment_view, 
	KaLocation, LaLocation, KdLocation, LdLocation, KsLocation, LsLocation;
float rotationAngle = 0.0f;
int toggleMode = 1;

float angleYRotate;
float angleXRotate;
float cameraDis;
float angleYZ;
float angleXZ;
vec3 eyePosition;

vec3 LaStar = vec3(1.0f, 1.0f, 1.0f);
vec3 LdStar = vec3(1.0f, 1.0f, 1.0f);
vec3 LsStar = vec3(1.0f, 1.0f, 1.0f);
vec3 KaStar = vec3(1.0f, 1.0f, 1.0f);
vec3 KdStar = vec3(1.0f, 1.0f, 1.0f);
vec3 KsStar = vec3(1.0f, 1.0f, 1.0f);

vec3 LaShip = vec3(0.0f, 0.0f, 0.5f);
vec3 LdShip = vec3(0.0f, 0.0f, 0.7f);
vec3 LsShip = vec3(1.0f, 1.0f, 1.0f);
vec3 KaShip = vec3(1.0f, 1.0f, 1.0f);
vec3 KdShip = vec3(1.0f, 1.0f, 1.0f);
vec3 KsShip = vec3(1.0f, 1.0f, 1.0f);

vec3 LaMars = vec3(0.15f, 0.0f, 0.0f);
vec3 LdMars = vec3(0.3f, 0.0f, 0.0f);
vec3 LsMars = vec3(1.0f, 0.0f, 0.0f);
vec3 KaMars = vec3(1.0f, 1.0f, 1.0f);
vec3 KdMars = vec3(0.5f, 0.0f, 0.0f);
vec3 KsMars = vec3(0.01f, 0.0f, 0.0f);


float flyoverCamRotationAngle;
float flyoverRotationRads;
float flyoverCamRadius;
float flyoverCamOffset;
float flyoverCamLookAroundAngle = 0.0f;

float shipAngle;

vec3 flyoverCamPosition, flyoverCamLookAt, flyoverCamUp;

bool wireframe;
bool paused = false;
float startPause, endPause, prevTime;
Ship* ship;
Mesh** meshShip;

GLuint* positionsVboShip;
GLuint* normalsVboShip;
GLuint* vaoShip;

GLuint vaoMars, positionsVboMars, normalsVboMars;
GLuint vaoStarfield, positionsVboStarfield, normalsVboStarfield;
mat4* modelMatrixShip;
int meshNumShip;
Mesh* meshMars;
Mesh* meshStarfield;
MarsModel* marsModel;
StarfieldModel* starfieldModel;
mat4 modelMatrixMars, modelMatrixStarfield;
float	aspectRatio = (float) g_gl_width / g_gl_height;
float fov;
// debuging log files
bool restart_gl_log() {
	ofstream file;
	file.open(GL_LOG_FILE);
	if (!file) {
		fprintf(stderr, "ERROR: could not open %s log file for writing\n", GL_LOG_FILE);
		return false;
	}
	time_t now = time(NULL);
	file << GL_LOG_FILE << "  log. local time " << put_time(localtime(&now), "%F %T") << "\n";
	file.close();
	return true;
}

bool gl_log(const char* message, const char* filename, int line) {
	ofstream file;
	file.open("example.txt");
	if (!file) {
		fprintf(stderr, "ERROR: could not open %s for writing\n", GL_LOG_FILE);
		return false;
	}
	file << filename << ":" << line << " " << message << "\n";
	file.close();
	return true;
}

static void glfw_error_callback(int error, const char* description) {
	fputs(description, stderr);
	gl_log(description, __FILE__, __LINE__);
}

// angleYX represents the angle between the line and the xz plane
// angleX represents the angle between the line and x axies
void rotateY(float angle) {
	float angleR = (float) angle / 180 * PI;

	angleYRotate += angleR; // TODO: limit
	if (angleYRotate > 2 * PI) {
		angleYRotate -= 2 * PI;
	}
	else if (angleYRotate < -2 * PI) {
		angleYRotate += 2 * PI;
	}

	float projXZ = abs(cameraDis * cos(angleXZ));
	float x = projXZ * sin(angleYRotate);
	float y = eyePosition.y;
	float z = projXZ * cos(angleYRotate);

	float side = sqrt(z * z + y * y);
	// range
	angleYZ = acos(side / cameraDis);
	eyePosition = vec3(x, y, z);
}

void rotateXZ(float angle) {
	float angleR = (float) angle / 180 * PI;
	angleXZ += angleR;
	float limit = (float) 89 / 180 * PI;
	if (angleXZ > limit) {
		angleXZ = limit;
	}
	else if (angleXZ < -limit) {
		angleXZ = -limit;
	}
	else if (angleXZ < limit && angleXZ > -limit) {
		float projXZ = abs(cameraDis * cos(angleXZ));
		float x = projXZ * sin(angleYRotate);
		float y = cameraDis * sin(angleXZ);
		float z = projXZ * cos(angleYRotate);

		eyePosition = vec3(x, y, z);
	}

}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (action == GLFW_PRESS || action == GLFW_REPEAT) {
		switch (key) {
		case GLFW_KEY_ESCAPE:
			glfwSetWindowShouldClose(window, GL_TRUE);
			break;//end GLFW_KEY_ESCAPE

		case GLFW_KEY_RIGHT:
			if(toggleMode == 1 || toggleMode == 2 || toggleMode == 5){
				rotateY(3);
				view_mat = lookAt(eyePosition, vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));
			}
			else if (toggleMode == 3){
				flyoverCamLookAroundAngle += 3.0f;
			}
			break;//end GLFW_KEY_RIGHT
		case GLFW_KEY_LEFT:
			if(toggleMode == 1 || toggleMode == 2 || toggleMode == 5){
				rotateY(-3);
				view_mat = lookAt(eyePosition, vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));
			}
			else if (toggleMode == 3){
				flyoverCamLookAroundAngle -= 3.0f;
			}
			break;//end GLFW_KEY_LEFT
		case GLFW_KEY_UP:
			if(toggleMode == 1 || toggleMode == 2 || toggleMode == 5){
				rotateXZ(3);
				view_mat = lookAt(eyePosition, vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));
			}
			break;//end GLFW_KEY_UP
		case GLFW_KEY_DOWN:
			if(toggleMode == 1 || toggleMode == 2 || toggleMode == 5){
				rotateXZ(-3);
				view_mat = lookAt(eyePosition, vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));
			}
			break;//end GLFW_KEY_DOWN
		case GLFW_KEY_W:
			wireframe = !wireframe;
			if (wireframe) {
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			}
			else {
				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			}
			break;//end GLFW_KEY_W
		case GLFW_KEY_F1:
			toggleMode++;
			if (toggleMode > 5) toggleMode = 1;
			cout << toggleMode << endl;
			switch (toggleMode){
			case 1:
				cameraDis = cameraDis / 10.0f;
				view_mat = lookAt(eyePosition, vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));
				break;
			case 2:
				break;
			case 3:
				//this is the cameras distance from the origin
				flyoverCamRadius = 1.5f;
				//this is the angle in radians of the offset of where the camera is looking at
				flyoverCamOffset = 1.107f;

				flyoverCamLookAroundAngle = 0.0f;
				flyoverCamPosition = vec3(0.0f, 0.0f, flyoverCamRadius);
				flyoverCamLookAt = vec3(flyoverCamRadius * sin(flyoverCamOffset), 
					0.0f, flyoverCamRadius * cos(flyoverCamOffset));
				flyoverCamUp = vec3(0.0f, 0.0f, 1.0f);
				view_mat = lookAt(flyoverCamPosition, flyoverCamLookAt, flyoverCamUp);
				break;
			case 4:
				//this is the angle in radians of the offset of where the camera is looking at
				flyoverCamOffset = 1.827f;

				flyoverCamLookAroundAngle = 0.0f;
				flyoverCamPosition = vec3(0.0f, 0.0f, flyoverCamRadius);
				flyoverCamLookAt = vec3(flyoverCamRadius * sin(flyoverCamOffset), 
					0.0f, 
					flyoverCamRadius * cos(flyoverCamOffset));
				flyoverCamUp = vec3(0.0f, 0.0f, 1.0f);
				view_mat = lookAt(flyoverCamPosition, flyoverCamLookAt, flyoverCamUp);
				break;
			case 5:
				cameraDis = cameraDis * 10.0f;
				view_mat = lookAt(vec3(0.0f, 0.0f, cameraDis), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));
				break;
			default:
				toggleMode = 1;
				break;
			}//end switch(toggleMode)
			break;
		case GLFW_KEY_P:
			if(toggleMode == 1 || toggleMode == 2 ||toggleMode == 5){
				paused = !paused;
				if(paused){
					startPause = (float) glfwGetTime();
				}
				else{
					endPause = (float) glfwGetTime();
					prevTime += endPause - startPause;
				}
			}
			break;
		case GLFW_KEY_PAGE_UP:
			fov -= 2.0f;
			projectMat = perspective(fov, aspectRatio, .01f, 100.0f);
			break;
		case GLFW_KEY_PAGE_DOWN:
			fov += 2.0f;
			projectMat = perspective(fov, aspectRatio, .01f, 100.0f);
			break;
		}//endif press and repeat
	}//end switch(key)


}//end key_callback

static void glfw_window_size_callback(GLFWwindow* window, int width, int height) {
	g_gl_width = width;
	g_gl_height = height;

	aspectRatio = (float) g_gl_width / g_gl_height;
	projectMat = perspective(fov, aspectRatio, .01f, 100.0f);
	/* update any perspective matrices used here */
}

void createVBO(Mesh* mesh, GLuint& positionsVbo, GLuint& normalsVbo) {

	vec3* positions = mesh->getTriangle();
	vec3* normals = mesh->getNormal();
	int vertNum = mesh->getDrawVerticesNum();

	glGenBuffers(1, &positionsVbo);
	glBindBuffer(GL_ARRAY_BUFFER, positionsVbo);
	glBufferData(GL_ARRAY_BUFFER, vertNum * sizeof(vec3), positions, GL_STATIC_DRAW);

	glGenBuffers(1, &normalsVbo);
	glBindBuffer(GL_ARRAY_BUFFER, normalsVbo);
	glBufferData(GL_ARRAY_BUFFER, vertNum * sizeof(vec3), normals, GL_STATIC_DRAW);
}

void createVBOShip() {
	modelMatrixShip = ship->getModelMatrix();
	meshShip = ship->getMesh();

	for (int i = 0; i < meshNumShip; i++) {
		createVBO(meshShip[i], positionsVboShip[i], normalsVboShip[i]);
	}
}

void createVBOMars() {
	modelMatrixMars = marsModel->getModelMatrix()[0];
	meshMars = marsModel->getMesh()[0];
	createVBO(meshMars, positionsVboMars, normalsVboMars);
}

void createVBOStarfield() {
	modelMatrixStarfield = starfieldModel->getModelMatrix()[0];
	meshStarfield = starfieldModel->getMesh()[0];

	createVBO(meshStarfield, positionsVboStarfield, normalsVboStarfield);
}

void createVAO(GLuint& vao, GLuint& positionsVbo, GLuint& normalsVbo) {
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	glBindBuffer(GL_ARRAY_BUFFER, positionsVbo);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (GLubyte *) NULL);
	glBindBuffer(GL_ARRAY_BUFFER, normalsVbo);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (GLubyte *) NULL);

	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
}

void createVAOShip() {
	for (int i = 0; i < meshNumShip; i++) {
		createVAO(vaoShip[i], positionsVboShip[i], normalsVboShip[i]);
	}
}

void createVAOMars() {
	createVAO(vaoMars, positionsVboMars, normalsVboMars);
}

void createVAOStarfield() {
	createVAO(vaoStarfield, positionsVboStarfield, normalsVboStarfield);
}

string readFile(const char * filePath){
	string content;
	ifstream fileStream(filePath, std::ios::in);

	if (!fileStream.is_open()){
		cerr << "could not read file " << filePath << ". File does not exist." << endl;
	}

	string line = "";
	while (!fileStream.eof()){
		getline(fileStream, line);
		content.append(line + "\n");
	}

	fileStream.close();
	return content;
}

void createShader() {
	GLuint vs = glCreateShader(GL_VERTEX_SHADER);
	string vertShaderStr = readFile("basic.vert");
	const char * vertShaderSrc = vertShaderStr.c_str();
	glShaderSource(vs, 1, &vertShaderSrc, NULL);
	glCompileShader(vs);

	//check compile
	GLint result;
	int logLength;
	glGetShaderiv(vs, GL_COMPILE_STATUS, &result);
	glGetShaderiv(vs, GL_INFO_LOG_LENGTH, &logLength);
	std::vector<char> vertShaderError(logLength);
	glGetShaderInfoLog(vs, logLength, NULL, &vertShaderError[0]);
	std::cout << &vertShaderError[0] << std::endl;

	GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
	string fragShaderStr = readFile("basic.frag");
	const char * fragShaderSrc = fragShaderStr.c_str();
	glShaderSource(fs, 1, &fragShaderSrc, NULL);
	glCompileShader(fs);

	shader_programme = glCreateProgram();
	glAttachShader(shader_programme, fs);
	glAttachShader(shader_programme, vs);
	glLinkProgram(shader_programme);
}

void _update_fps_counter(GLFWwindow* window) {
	static double previous_seconds = glfwGetTime();
	static int frame_count;
	double current_seconds = glfwGetTime();
	double elapsed_seconds = current_seconds - previous_seconds;
	if (elapsed_seconds > 0.25) {
		previous_seconds = current_seconds;
		double fps = (double) frame_count / elapsed_seconds;
		char tmp[128];
		sprintf(tmp, "opengl @ fps: %.2lf", fps);
		glfwSetWindowTitle(window, tmp);
		frame_count = 0;
	}
	frame_count++;
}

void drawModel(bool drawPoints, GLuint shaderProgramme, GLuint modelLocation, mat4 modelMatrix, GLuint vao, int vertNum) {
	glUseProgram(shader_programme);
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, value_ptr(modelMatrix));
	glBindVertexArray(vao);
	if (drawPoints) {
		glDrawArrays(GL_POINTS, 0, vertNum);
	}
	else {
		glDrawArrays(GL_TRIANGLES, 0, vertNum);
	}

}

// TODO: change different shader programme for spaceship and mars
void drawShip() {
	//glUseProgram(shader_programme);
	if(toggleMode == 4){



	}
	int vertNum;
	for (int i = 0; i < meshNumShip; i++) {
		vertNum = meshShip[i]->getDrawVerticesNum();
		drawModel(false, shader_programme, modelLocation, modelMatrixShip[i], vaoShip[i], vertNum);
	}
}

void loadShipADS(){
	glUniform3fv(LaLocation, 1, value_ptr(LaShip));
	glUniform3fv(LdLocation, 1, value_ptr(LdShip));
	glUniform3fv(LsLocation, 1, value_ptr(LsShip));
	glUniform3fv(KaLocation, 1, value_ptr(KaShip));
	glUniform3fv(KdLocation, 1, value_ptr(KdShip));
	glUniform3fv(KsLocation, 1, value_ptr(KsShip));

}

void drawMars() {
	int vertNum = meshMars->getDrawVerticesNum();
	if(toggleMode == 2 && !paused){
		modelMatrixMars = rotate(modelMatrixMars, rotationAngle, vec3(0.0f, 1.0f, 0.0f));
	}
	drawModel(false,shader_programme, modelLocation, modelMatrixMars, vaoMars, vertNum);	
}

void loadMarsADS(){
	glUniform3fv(LaLocation, 1, value_ptr(LaMars));
	glUniform3fv(LdLocation, 1, value_ptr(LdMars));
	glUniform3fv(LsLocation, 1, value_ptr(LsMars));
	glUniform3fv(KaLocation, 1, value_ptr(KaMars));
	glUniform3fv(KdLocation, 1, value_ptr(KdMars));
	glUniform3fv(KsLocation, 1, value_ptr(KsMars));
}

void drawStarfield() {
	int vertNum = meshStarfield->getDrawVerticesNum();
	if(toggleMode == 5 && !paused){
		modelMatrixStarfield = rotate(modelMatrixStarfield, rotationAngle, vec3(0.0f, 1.0f, 0.0f));
	}
	drawModel(true, shader_programme, modelLocation, modelMatrixStarfield, vaoStarfield, vertNum);
}

void loadStarADS(){
	glUniform3fv(LaLocation, 1, value_ptr(LaStar));
	glUniform3fv(LdLocation, 1, value_ptr(LdStar));
	glUniform3fv(LsLocation, 1, value_ptr(LsStar));
	glUniform3fv(KaLocation, 1, value_ptr(KaStar));
	glUniform3fv(KdLocation, 1, value_ptr(KdStar));
	glUniform3fv(KsLocation, 1, value_ptr(KsStar));
}

void render()
{
	// updating rates
	_update_fps_counter(window);
	// wipe the drawing surface clear
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//glClearColor(0.0f, 1.0f, 0.0f, 1.0f);
	// change viewport for resizing

	glViewport(0, 0, g_gl_width, g_gl_height);

	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, value_ptr(projectMat));
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, value_ptr(view_mat));
	glUniformMatrix4fv(fragment_view, 1, GL_FALSE, value_ptr(view_mat));

	if(toggleMode == 1){

		//change diffuse, ambient, spec values
		loadStarADS();
		drawStarfield();
		//ship->rotate(glfwGetTime());
		view_mat = lookAt(eyePosition, vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));

		//change diffuse, ambient, spec values
		loadShipADS();
		drawShip();
		ship->updateModelMatrix(shipAngle);
	}
	else if(toggleMode == 2){

		//change diffuse, ambient, spec
		loadStarADS();
		drawStarfield();
		view_mat = lookAt(eyePosition, vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));

		//change ambient and diffuse and specular values
		loadMarsADS();
		drawMars();
	}
	else if (toggleMode == 3){
		view_mat = lookAt(flyoverCamPosition, flyoverCamLookAt, flyoverCamUp);

		//change ambient, diffuse specular
		loadStarADS();
		drawStarfield();

		//change ambient, diffuse, specular
		loadMarsADS();
		drawMars();
	}
	else if (toggleMode == 4){
		view_mat = lookAt(flyoverCamPosition, flyoverCamLookAt, flyoverCamUp);
		loadStarADS();
		drawStarfield();
		loadMarsADS();
		drawMars();
		loadShipADS();
		drawShip();
	}
	else if(toggleMode == 5){
		loadStarADS();
		drawStarfield();
	}
}


void update(float secondsElapsed) {
	const GLfloat degreesPerSecond = 10.0f;
	rotationAngle = secondsElapsed * degreesPerSecond;
	if (rotationAngle > 360.0f) rotationAngle -= 360.0f;
}

void cameraRevolve(float secondsElapsed){

	const float degreesPerSecond = 10.0f;
	flyoverCamRotationAngle += secondsElapsed * degreesPerSecond;
	flyoverRotationRads = flyoverCamRotationAngle / 180.0f * PI;
	if (flyoverRotationRads > 2 * PI) flyoverRotationRads -= 2 * PI;

	vec3 flyoverCamLookAtTemp = vec3(flyoverCamRadius * sin(flyoverRotationRads + flyoverCamOffset),
		0,
		flyoverCamRadius * cos(flyoverRotationRads + flyoverCamOffset));
	flyoverCamPosition = vec3(flyoverCamRadius * sin(flyoverRotationRads),
		0,
		flyoverCamRadius * cos(flyoverRotationRads));
	flyoverCamUp = vec3(sin(flyoverRotationRads), 0, cos(flyoverRotationRads));

	flyoverCamLookAt = vec3(vec4(flyoverCamLookAtTemp, 1.0f) * rotate(mat4(1.0f), flyoverCamLookAroundAngle, flyoverCamUp));
}

int main(int argc, const char* argv []) {
	fov = 35.0f;
	aspectRatio = (float) g_gl_width / g_gl_height;
	projectMat = perspective(fov, aspectRatio, 0.01f, 100.0f);

	Globals& globals = Globals::instance();
	Ship& shipRef = globals.getShip();
	ship = &shipRef; // pointer pointing to the static ship reference

	meshNumShip = ship->getMeshNum();
	positionsVboShip = new GLuint[meshNumShip];
	normalsVboShip = new GLuint[meshNumShip];
	vaoShip = new GLuint[meshNumShip];

	const char* filename = NULL;
	if (argc <= 1 || argc >= 3) {
		fprintf(stderr, "ERROR: please input filename");
	}
	else {
		filename = argv[1];
	}

	marsModel = new MarsModel(filename);
	starfieldModel = new StarfieldModel();
	char message[256];
	sprintf(message, "starting GLFW %s", glfwGetVersionString());
	assert(gl_log(message, __FILE__, __LINE__));
	glfwSetErrorCallback(glfw_error_callback);
	if (!glfwInit()) {
		fprintf(stderr, "ERROR: could not start GLFW3\n");
		return 1;
	}

	// anti-aliasing
	glfwWindowHint(GLFW_SAMPLES, 4);
	window = glfwCreateWindow(g_gl_width, g_gl_height, "Mars", NULL, NULL);
	if (!window) {
		fprintf(stderr, "ERROR: could not open window with GLFW3\n");
		glfwTerminate();
		return 1;
	}
	glfwMakeContextCurrent(window);
	glfwSetKeyCallback(window, key_callback);
	glfwSetWindowSizeCallback(window, glfw_window_size_callback);
	// start GLEW extension handler
	glewInit();
	// get version info
	const GLubyte* renderer = glGetString(GL_RENDERER); // get renderer string
	const GLubyte* version = glGetString(GL_VERSION); // version as a string
	printf("Renderer: %s\n", renderer);
	printf("OpenGL version supported %s\n", version);

	wireframe = false;
	// tell GL to only draw onto a pixel if the shape is closer to the viewer
	glEnable(GL_DEPTH_TEST); // enable depth-testing
	glDepthFunc(GL_LESS); // depth-testing interprets a smaller value as "closer"

	glfwSetKeyCallback(window, key_callback);
	glEnable(GL_DEPTH_TEST);
	//glEnable(GL_CULL_FACE); // cull face
	//glCullFace(GL_FRONT); // cull back face

	createVBOShip();
	createVAOShip();

	createVBOMars();
	createVAOMars();

	createVBOStarfield();
	createVAOStarfield();

	createShader();
	glUseProgram(shader_programme);

	viewLocation = glGetUniformLocation(shader_programme, "view");
	projectionLocation = glGetUniformLocation(shader_programme, "projection");
	modelLocation = glGetUniformLocation(shader_programme, "model");
	fragment_view = glGetUniformLocation(shader_programme, "view_matrix");
	KaLocation = glGetUniformLocation(shader_programme, "Ka"); 
	LaLocation = glGetUniformLocation(shader_programme, "La");
	KdLocation = glGetUniformLocation(shader_programme, "Kd");
	LdLocation = glGetUniformLocation(shader_programme, "Ld");
	KsLocation = glGetUniformLocation(shader_programme, "Ks");
	LsLocation = glGetUniformLocation(shader_programme, "Ls");

	cameraDis = 5.0f;

	eyePosition = vec3(0.0f, 0.0f, cameraDis); // distance
	// TODO: change to globals
	angleXZ = 0.0f;
	angleYZ = 0.0f;
	angleYRotate = 0.0f;
	angleXRotate = 0.0f;

	float speed = 1.0f;
	float last_position = 0.0f;

	view_mat = lookAt(eyePosition, vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));

	prevTime = (float) glfwGetTime();
	while (!glfwWindowShouldClose(window)) {
		shipAngle += 0.01f;
		if(!paused){
			float nowTime = (float)glfwGetTime();
			float timeDiff = nowTime - prevTime;
			update(timeDiff);
			cameraRevolve(timeDiff);
			prevTime = nowTime;
		}
		render();
		// update other events like input handling 
		glfwPollEvents();
		// put the stuff we've been drawing onto the display
		glfwSwapBuffers(window);
	}

	// close GL context and any other GLFW resources
	// TODO: detach shaders
	glfwTerminate();
	return 0;
}