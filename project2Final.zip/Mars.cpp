#include "mesh.h"
#include "globals.h"
using namespace std;
using namespace glm;

float* radiusData;
const char* filename;
// TODO: delete global stacks and slices
Mars::Mars() {
	Globals& globals = Globals::instance();
	filename = globals.getFilename();
	loadData();
	setDrawVerticesNum(stacks * slices *  2 * 3);
	vertices = new vec3[size];
	normals = new vec3[size];
	calculateVertices();
	factor();
	calculateNormals();
}

// load mars data into the mesh
// first line of the file specifies slices and stacks
void Mars::loadData() {
	// read files, low resolution for debugging

	ifstream mars_file;
	mars_file.open(filename);
	if (mars_file.is_open()) {
		string word;
		mars_file >> word;
		slices = stoi(word) - 1;
		mars_file >> word;
		stacks = stoi(word) - 1;
		// number of the vertices, from file
		rowNum = stacks + 1;
		colNum = slices + 1;
		size = rowNum * colNum;
		radiusData = new float[size];
		
		// read in altitude;
		// scale
		float temp;
		int i = 0;
		while (mars_file >> word) {
			temp = (float) atof(word.c_str());
			radiusData[i] = temp;
			i++;
		}
		if (i != size) {
			fprintf(stderr, "the size of data does not respond to the row "
				"and column number specified in the first row");
		}
		mars_file.close();
	}
}

void Mars::factor() {
	float scale;
	int i = 0;
	float temp = radiusData[0];
	// top row
	while (i < colNum - 1) {
		radiusData[i++] = temp;
	}

	while (i < size - colNum) {
		// right edge
		if (i % colNum == colNum - 1) {
			radiusData[i++] = radiusData[i - colNum + 1];
		}
		i++;
	}
		
	// bottom row
	temp = radiusData[i];
	while (i < size) {
		radiusData[i++] = temp;
	}

	for (int i = 0; i < size; i++) {
		scale = radiusData[i];
		scale = 1.0f + 0.03f * scale;
		vertices[i].x *= scale;
		vertices[i].y *= scale;
		vertices[i].z *= scale;
	}
}