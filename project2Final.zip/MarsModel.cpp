#pragma once
#include "Model.h"
#include "globals.h"
using namespace glm;

MarsModel::MarsModel(const char * fileName){
	meshArray = new Mesh*[1];
	modelMatrix = new mat4[1];
	meshNum = 1;
	Globals& globals = Globals::instance();
	globals.setFilename(fileName);
	setMesh();
	setModelMatrix();
}

void MarsModel::setMesh() {
	meshArray[0] = new Mars();
}

void MarsModel::setModelMatrix() {
	modelMatrix[0] = scale(mat4(1.0f), vec3(0.12f, 0.12f, 0.12f));
}