#include "mesh.h"
using namespace glm;
using namespace std;

Mesh::Mesh() {

}

void Mesh::iniMesh(int stacks, int slices) {
	this->stacks = stacks;
	this->slices = slices;
	rowNum = stacks + 1;
	colNum = slices + 1;
	setDrawVerticesNum(stacks * slices * 2 * 3);
	size = rowNum * colNum;
	vertices = new vec3[size];
	normals = new vec3[size];
	calculateVertices();
	calculateNormals();
}

int Mesh::getSize() {
	return size;
}

void Mesh::setDrawVerticesNum(int vertNum) {
	this->vertNum = vertNum;
}

int Mesh::getDrawVerticesNum() {

	return vertNum;
}

void Mesh::print() {
	for (int i = 0; i < size; i++) {
		printf("vertex %d: (%f, %f, %f)\n", i , vertices[i].x, 
				vertices[i].y, vertices[i].z);
	}
}

// both row and column starts from 0
int Mesh::getIndex(glm::vec2 rowCol) {
	int row = (int)rowCol.x;
	int col = (int)rowCol.y;
	int index = row * (slices + 1) + col;
	return index;
}

vec2 Mesh::getRowCol(int index) {
	int row = index / (slices + 1);
	int col = index % (slices + 1);
	return vec2(row, col);
}

/*	counter clockwise
	getNeighbors for the vertices, exclude edges
	all 6 neighbors
	default: cylinder
*/
int * Mesh::cylinNeighbors(int index) {
	vec2 rowCol = getRowCol(index);
	int row = (int)rowCol.x;
	int col = (int)rowCol.y;
	//printf("row=%d, col=%d\n", row, col);
	//test for cylinder !!
		//if the specific neighbor is null, set indx as - 1
	if (row > 0 && row < rowNum - 1 && col > 0 && col < colNum - 1) {
		neighbors[0] = getIndex(vec2(row - 1, col));
		neighbors[1] = getIndex(vec2(row, col - 1));
		neighbors[2] = getIndex(vec2(row + 1, col - 1));
		neighbors[3] = getIndex(vec2(row + 1, col));
		neighbors[4] = getIndex(vec2(row, col + 1));
		neighbors[5] = getIndex(vec2(row - 1, col + 1));
	}
	else {
		cylinEdgeNeighbors(index);
	}// TODO: print error

	return neighbors;
}

void Mesh::cylinEdgeNeighbors(int index) {
	vec2 rowCol = getRowCol(index);
	int row = (int)rowCol.x;
	int col = (int)rowCol.y;
	int i = 0;

	if (row == 0) {
		// top row 
		neighbors[0] = -1;
		neighbors[3] = getIndex(vec2(row + 1, col));
		neighbors[5] = -1;
		if (col == 0) {
			// top left corner
			neighbors[1] = getIndex(vec2(row, colNum - 2));
			neighbors[2] = getIndex(vec2(row + 1, colNum - 2));
			neighbors[4] = getIndex(vec2(row, col + 1));
		}	// top right corner
		else if (col == colNum - 1) {
			neighbors[1] = getIndex(vec2(row, col - 1));
			neighbors[2] = getIndex(vec2(row + 1, col - 1));
			neighbors[4] = getIndex(vec2(row, 1));
		}
		else {
			// top edge
			neighbors[1] = getIndex(vec2(row, col - 1));
			neighbors[2] = getIndex(vec2(row + 1, col - 1));
			neighbors[4] = getIndex(vec2(row, col + 1));
		}
	} // bottom row
	else if (row == rowNum - 1) {
		neighbors[0] = getIndex(vec2(row - 1, col));
		neighbors[2] = -1;
		neighbors[3] = -1;
		if (col == 0) {
			// bottom left corner
			neighbors[1] = getIndex(vec2(row, colNum - 2));
			neighbors[4] = getIndex(vec2(row, col + 1));
			neighbors[5] = getIndex(vec2(row - 1, col + 1));
		}
		else if (col == colNum - 1) {
			// bottom right corner
			neighbors[1] = getIndex(vec2(row, col - 1));
			neighbors[4] = getIndex(vec2(row, 1));
			neighbors[5] = getIndex(vec2(row - 1, 1));
		}
		else {
			// bottom edge
			neighbors[1] = getIndex(vec2(row, col - 1));
			neighbors[4] = getIndex(vec2(row, col + 1));
			neighbors[5] = getIndex(vec2(row - 1, col + 1));
		}
	}
	else {
		// left edge
		neighbors[0] = getIndex(vec2(row - 1, col));
		neighbors[3] = getIndex(vec2(row + 1, col));
		if (col == 0) {
			neighbors[1] = getIndex(vec2(row, colNum - 2));
			neighbors[2] = getIndex(vec2(row + 1, colNum - 2));
			neighbors[4] = getIndex(vec2(row, col + 1));
			neighbors[5] = getIndex(vec2(row - 1, col + 1));

		} // right edge
		else if (col == slices) {
			neighbors[1] = getIndex(vec2(row, col - 1));
			neighbors[2] = getIndex(vec2(row + 1, col - 1));
			neighbors[4] = getIndex(vec2(row, 1));
			neighbors[5] = getIndex(vec2(row - 1, 1));
		}
	}
}

void Mesh::printNeighbors() {
	// debuging
	for (int i = 0; i < 6; i++) {
		printf("%d ", neighbors[i]);
	}
}

void printPoint(vec3 a) {
	printf("(%f,%f,%f)\n", a.x, a.y, a.z);
}
/* row by row
** cylinder starts from the second row
**/
vec3 * Mesh::getTriangle() {
	positions = new vec3[stacks * slices * 2 * 3];
	int j = 0;
	
	// start drawing, drawing two right triangles
	for (int i = colNum; i < size; i++) { 
		if (i % colNum != colNum - 1) {
			getNeighbors(i); 
			positions[j++] = vertices[i];
			positions[j++] = vertices[neighbors[4]];
			positions[j++] = vertices[neighbors[5]];
			positions[j++] = vertices[i];
			positions[j++] = vertices[neighbors[5]];
			positions[j++] = vertices[neighbors[0]];
		}
	}
	return positions;
}

vec3* Mesh::getVertices() {
	return vertices;
}

vec3 Mesh::normalizedNormal(vec3 a, vec3 b, vec3 c) {
	vec3 normal;
	vec3 ba = b - a;
	vec3 ca = c - a;

	if (ba != vec3(0.0f) && ca != vec3(0.0f) && ba != ca) {
		normal = normalize(cross(ba, ca));
	}
	else {
		normal = vec3(0.0f);
	}
	
	return normal;
}

void Mesh::baseNormal(int index) {
	// the normal case
	// base case all 6 neighbors
	float num = 6.0f;
	vec3 sum = vec3(0.0f);
	vec3 result;
	vec3 ori = vertices[index];

	for (int i = 0; i < 5; i++) {
		sum += normalizedNormal(ori, vertices[neighbors[i]], vertices[neighbors[i + 1]]);
	}
	sum += normalizedNormal(ori, vertices[neighbors[5]], vertices[neighbors[0]]);
	result = vec3(sum.x / num, sum.y / num, sum.z / num);
	normals[index] = result; 
}

vec3* Mesh::getNormal() {
	vec3* vertices_normal = new vec3[stacks * slices * 2 * 3];
	int j = 0;

	// start drawing, drawing two right triangles
	for (int i = colNum; i < size; i++) {
		if (i % colNum != colNum - 1) {
			getNeighbors(i);
			vertices_normal[j++] = normals[i];
			vertices_normal[j++] = normals[neighbors[4]];
			vertices_normal[j++] = normals[neighbors[5]];
			vertices_normal[j++] = normals[i];
			vertices_normal[j++] = normals[neighbors[5]];
			vertices_normal[j++] = normals[neighbors[0]];
		}
	}
	return vertices_normal;
}