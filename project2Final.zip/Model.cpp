#include "Model.h"
using namespace glm;
// TODO: initialise with size of the models
// TODO: delete all the new classes
Model::Model() {
}

Mesh** Model::getMesh() {
	return meshArray;
}

mat4* Model::getModelMatrix() {

	return modelMatrix;
}

int Model::getMeshNum() {
	return meshNum;
}