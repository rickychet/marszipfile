#pragma once

#include <glm\glm.hpp>
#include <glm\gtx\transform.hpp>
#include <GL/glew.h>
#include "mesh.h"

class Model{
protected:
	int meshNum;
	glm::mat4* modelMatrix;
	Mesh ** meshArray;
	Model();
public:
	Mesh** getMesh();
	glm::mat4* getModelMatrix();
	virtual void setMesh(){};
	virtual void setModelMatrix(){};
	int getMeshNum();
};

class Ship : public Model {
private:


	void setMesh();
	void setModelMatrix();
	void setSpherePairs();
public:
	Ship();
	void updateModelMatrix(float angle);
};

class MarsModel : public Model {
private:
	int stacks, slices;
	const char* filename;
	void iniMars();
	void setMesh();
	void setModelMatrix();
public:
	MarsModel(const char * fileName);
};

class StarfieldModel : public Model {
private:
	int stacks, slices;
	void iniMars();
	void setMesh();
	void setModelMatrix();
public:
	StarfieldModel();
};