#pragma once
#include "Model.h"

using namespace glm;
vec3 pos[4];
vec3 backPos[4];
float dis = 0.7f;
float y = -0.7f;
float yOffset = -0.7f;
float yOffset2 = yOffset / 2.0f + 0.1f;
vec3 scaleWhole = vec3(0.8f, 0.8f, 0.8f);
vec3 scaleVec1 = vec3(0.02f, 0.02f, 0.02f);
vec3 scaleVec2 = vec3(0.02f, 0.025f, 0.02f);
vec3 scaleVec3 = vec3(0.05f, 0.15f, 0.05f);

Ship::Ship(){
	meshArray = new Mesh*[17];
	modelMatrix = new mat4[17];
	meshNum = 17;
	setMesh();
	setModelMatrix();
}

void Ship::setMesh() {
	// spheres
	int i = 0;
	while (i < meshNum - 1) {
		meshArray[i++] = new Sphere(30, 60);
		meshArray[i++] = new Sphere(30, 60);
		meshArray[i++] = new Cylinder(20, 40);
		meshArray[i++] = new Cylinder(20, 40);
	}
	meshArray[i] = new Sphere(60, 120);
}

void Ship::setModelMatrix() {
	updateModelMatrix(1.75 * PI);
}

void Ship::updateModelMatrix(float angle) {
	
	float x = cos(angle) * dis;
	float z = sin(angle) * dis;

	float dis2 = 0.42f;
	pos[0] = vec3(x, y, z);
	pos[1] = vec3(x, y + yOffset, z);
	pos[2] = vec3(x, y + yOffset2, z);
	pos[3] = vec3(cos(angle) * dis2, y + yOffset2, sin(angle) * dis2);

	for (int i = 0; i < 4; i++) {
		modelMatrix[i] = scale(mat4(1.0f), scaleWhole);
		modelMatrix[i] = translate(modelMatrix[i], pos[i]);
	}
	modelMatrix[meshNum - 1] = scale(mat4(1.0f), scaleWhole);

	for (int i = 0; i < 4; i++) {
		backPos[i] = -pos[i];
	}

	for (int i = 4; i < meshNum - 1; i++) {
		modelMatrix[i] = translate(modelMatrix[i - 4], backPos[i % 4]);
		modelMatrix[i] = rotate(modelMatrix[i], 90.0f, vec3(0.0f, 1.0f, 0.0f));
		modelMatrix[i] = translate(modelMatrix[i], pos[i % 4]);
	}

	for (int i = 3; i < meshNum - 1; i += 4) {
		float rotateAngle = angle - PI / 2;
		modelMatrix[i] = rotate(modelMatrix[i], 100.0f, vec3(cos(rotateAngle), 0.0f, sin(rotateAngle)));
	}

	for (int i = 0; i < meshNum - 1; i++) {
		modelMatrix[i] = scale(modelMatrix[i], scaleVec1);
	}
	modelMatrix[meshNum - 1] = rotate(modelMatrix[meshNum - 1],  angle / PI * 8.0f, vec3(0.0f, 1.0f, 0.0f));
	modelMatrix[meshNum - 1] = scale(modelMatrix[meshNum - 1], scaleVec3);
}