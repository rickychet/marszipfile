#include "mesh.h"
using namespace glm;
Sphere::Sphere() {

}
Sphere::Sphere(int stacks, int slices){
	iniMesh(stacks, slices);
}

void Sphere::calculateVertices() {

	float radius = 10.0f;
	float angleSlice = PI * 2.0f / (float) slices;
	float yStack = (2.0f * radius) / (float) stacks;
	int ctr = 0;
	float x, y, z, r, angle;

	// slices PI * 2 for duplicate right edge
	for (int i = 0; i < stacks + 1; i++) {
		y = radius - yStack * i;
		for (int j = 0; j < slices + 1; j++) {
			angle = angleSlice * j;
			r = sqrt(radius * radius - y * y);
			x = r * cos(angle);
			z = r * sin(angle);
			vertices[ctr].x = x;
			vertices[ctr].y = y;
			vertices[ctr].z = z;
			ctr++;
		}
	}
}

void Sphere::calculateNormals(){
	// top row
	int start = 0 + colNum;
	int end = start + colNum - 2;
	poleNormal(0, start, end, true);

	for (int i = colNum; i < size - colNum; i++) {
		getNeighbors(i);
		baseNormal(i);
	}
	// bottom row
	start = size - 2 * colNum;
	end = start + colNum - 2;
	poleNormal(size - colNum, start, end, false);
}

int* Sphere::getNeighbors(int index){
	cylinNeighbors(index);
	// wrap top and bottom
	vec2 rowCol = getRowCol(index);
	int row = (int)rowCol.x;
	int col = (int)rowCol.y;
	int i = 0;
	
	if (row == 0) {
		neighbors[0] = getIndex(vec2(stacks, col));
		if (col != slices) {
			neighbors[5] = getIndex(vec2(stacks, col + 1));
		}
		else {
			neighbors[5] = getIndex(vec2(stacks, 0));
		}
		
	}
	// bottom row
	else if (row == stacks) {
		neighbors[3] = getIndex(vec2(0, col));
		if (col != 0) {
			neighbors[2] = getIndex(vec2(0, col - 1));
		}
		else {
			neighbors[2] = getIndex(vec2(0, slices));
		}	
	}

	return neighbors;
}

void Sphere::poleNormal(int index, int start, int end, bool up) {
	vec3 sum = vec3(0.0f);
	float num = (float)slices;
	vec3 temp;

	vec3 ori = vertices[index];
	for (int j = start; j < end; j++) {
		sum += normalizedNormal(ori, vertices[j], vertices[j + 1]);
	}
	sum += normalizedNormal(ori, vertices[end], vertices[start]);
	
	temp = vec3(sum.x / num, sum.y / num, sum.z / num);
	if (!up) {
		temp = -temp;
	}
	int i = index;
	while (i < index + colNum) {
		normals[i++] = temp;
	}
}