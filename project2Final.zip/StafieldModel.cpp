#pragma once
#include "Model.h"
#include "globals.h"
using namespace glm;

StarfieldModel::StarfieldModel(){
	meshArray = new Mesh*[1];
	modelMatrix = new mat4[1];
	meshNum = 1;
	setMesh();
	setModelMatrix();
}

void StarfieldModel::setMesh() {
	meshArray[0] = new Starfield(60, 120);
}

void StarfieldModel::setModelMatrix() {
	modelMatrix[0] = scale(mat4(1.0f), vec3(0.2f, 0.2f, 0.2f));
}