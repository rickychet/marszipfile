#include "mesh.h"

using namespace glm;

Starfield::Starfield(){
}

Starfield::Starfield(int stacks, int slices){
	iniMesh(stacks, slices);
}

void Starfield::calculateVertices(){
	float radius = 50.0f;
	float angleSlice = PI * 2.0f / (float) slices;
	float yStack = (2.0f * radius) / (float) stacks;
	int ctr = 0;
	float x, y, z, r, angle;

	// slices PI * 2 for duplicate right edge
	for (int i = 1; i < stacks; i++) {
		y = radius - yStack * i;
		for (int j = 0; j < slices + 1; j++) {
			angle = angleSlice * j;
			r = sqrt(radius * radius - y * y);
			x = r * cos(angle);
			z = r * sin(angle);
			vertices[ctr].x = x + ((float) rand() / (float) RAND_MAX) / 0.1f;
			vertices[ctr].y = y + ((float) rand() / (float) RAND_MAX) / 0.1f;
			vertices[ctr].z = z + ((float) rand() / RAND_MAX) / 0.1f;
			ctr++;
		}
	}
}