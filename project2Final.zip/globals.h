#pragma once

#include "glm/glm.hpp"
#include "model.h"
#include <stdio.h>

class Globals
{
private:
	Globals(){};
	int data;
	float fov;

	float hither;
	float yon;

	bool wireframe;
	glm::vec3 eyePosition;

	float cameraDis;
	float angleXZ;
	float angleYZ;
	float angleYRotate;
	float angleXRotate; 
	int stacks, slices;

	const char* filename;
public:
	void setData(int stacks_read, int slices_read) {
		stacks = stacks_read;
		slices = slices_read;
	}

	static Globals& instance() {
		static Globals INSTANCE;
		return INSTANCE;
	}

	static Ship& getShip() {
		static Ship ship;
		return ship;
	}

	void setFilename(const char* filename) {
		this->filename = filename;
	}

	const char* getFilename() {
		return filename;
	}

	int getStacks() {
		return stacks;
	}

	int getSlices() {
		return slices;
	}
};