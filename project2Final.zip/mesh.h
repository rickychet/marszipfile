#pragma once

#define _USE_MATH_DEFINES
#define GLM_SWIZZLE // vec4 -> vec3

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <assert.h>
#include <time.h>
#include <iomanip>

#include <gl/glew.h>
#include <gl/freeglut.h>
#include <gl/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>

#define PI 3.14159f
class Mesh{

protected:
	int stacks, slices;
	int rowNum, colNum;
	int size;
	int neighbors[6]; // all 6 neighbors
	int neighborNum; 
	int vertNum;

	// TODO: free new!

	glm::vec3* positions;
	glm::vec3* vertices;
	glm::vec3* normals;

	float* factors;
	void iniMesh(int stacks, int slices);
	void baseNormal(int index);
	
	// initialise with sample data
	// slices: vertical stacks: horizontal 
public:
	Mesh();
	int getSize();
	void setDrawVerticesNum(int vertNum);
	int getDrawVerticesNum();
	void print();
	int getIndex(glm::vec2 rowCol);
	glm::vec2 getRowCol(int index);
	int* cylinNeighbors(int index); // index of the vertices 
	int getNeighborNum();
	void cylinEdgeNeighbors(int index);
	void printNeighbors();

	glm::vec3* getTriangle();
	glm::vec3* getNormal();
	glm::vec3* getVertices();
	virtual void calculateVertices(){};
	virtual void calculateNormals(){};
	glm::vec3 normalizedNormal(glm::vec3 a, glm::vec3 b, glm::vec3 c);
	virtual int* getNeighbors(int index) { return NULL; };
};

class Sphere : public Mesh
{
public:
	Sphere();
	Sphere(int stacks, int slices);
	void calculateVertices();
	void calculateNormals();
	int* getNeighbors(int index);
	void poleNormal(int index, int start, int end, bool up);
};

class Cylinder : public Mesh
{
public:
	Cylinder(int stacks, int slices);
	void calculateVertices();
	void calculateNormals();
	int* getNeighbors(int index);
};

class Mars : public Sphere
{
public:
	Mars();
	Mars(int stacks, int slices);
	void loadData();
	
	// override the parent Sphere calculateVertices function
	// by reading the altitudes data
	void factor();

};

class Starfield : public Sphere
{
public:
	Starfield();
	Starfield(int stacks, int slices);
	void calculateVertices();

};