#README - Project 2 - Tianxin Tang, Richard Barker

This project was built using freeglut, glew, and uses glfw3 for window and input handling to create modern GL graphics

This program has 5 modes to cycle through:
F1: Toggle modes
w: Toggle wireframe
esc: exit program
p: pause
Page Up: zoom in
Page Down: zoom out

Mode 1(on start up): a rotating space ship.
Arrow Keys: Move around the ship

Mode 2: Mars rotating
Arrow Keys: Move around Mars

Mode 3: First Person View from spaceship flying over Mars
Left/Right Arrow Keys: Look Left/Right


Mode 4: Third person "chase view" of the spaceship flying over Mars


Mode 5: Rotating starfield
Arrow keys: Move around starfield